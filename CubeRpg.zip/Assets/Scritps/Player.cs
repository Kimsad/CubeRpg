using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //�ӵ� ����

    public int HP = 10;

    public LayerMask checkLayer;

    public float speed = 0.5f;
    private float speedFactor = 0.5f;

    void Start()
    {
        
       
    }

    void Update()
    {
        MovePlayer();
        RotatePlayer();
    }

    void MovePlayer()
    {

        float x = Input.GetAxis("Horizontal");
        float y = Input.GetAxis("Vertical");

        Vector3 dir = new Vector3(x, 0, y) * speed * speedFactor * Time.deltaTime;

        transform.Translate(dir, Space.World);


    }

    void RotatePlayer()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray, out RaycastHit hitInfo, Mathf.Infinity, checkLayer))
        {
            Vector3 mousePositonInWorld = hitInfo.point;
            mousePositonInWorld.y = transform.position.y;

            Vector3 dir = mousePositonInWorld - transform.position;
            Quaternion targetRotaion = Quaternion.LookRotation(dir);
            transform.rotation = targetRotaion;
        }
    }
}
