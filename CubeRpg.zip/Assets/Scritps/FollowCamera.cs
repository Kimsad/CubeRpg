using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class FollowCamera : MonoBehaviour
{

    Transform target; // null
    Vector3 targetDistance;


    void LateUpdate()
    {
        //�÷��̾� ����
        //�÷��̾�� ī�޶��� ��ġ ����
        //�÷��̾� ��ġ�� ���� ī�޶� �̵�
        if (target == null)
        {
            {
                target = GameManager.Instance.Player.transform;
                targetDistance = transform.position - target.position;
            }
        }

         if (target == null) return;

        if (GameManager.Instance.Player == null)
        {
            return;
        }

            transform.position = target.position + targetDistance;

        //GameManager.Instance player;

    }
}
